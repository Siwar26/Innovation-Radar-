import { runSync } from "../../shared/syncCore.js";
import { runWatchlistSync } from "../../shared/watchlistCore.js";

export default async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405 });
  }
  try {
    const result = await runSync();
    const watchlist = await runWatchlistSync();
    return new Response(JSON.stringify({ ok: true, ...result, watchlist }), {
      headers: { "content-type": "application/json" }
    });
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: e.message }), {
      status: 500,
      headers: { "content-type": "application/json" }
    });
  }
};

export const config = {
  path: "/api/sync-now"
};
