import { addWatchlistItem } from "../../shared/watchlistCore.js";

export default async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405 });
  }
  try {
    const body = await req.json();
    const { type, name, url, feedUrl } = body || {};
    if (!type || !["client", "competitor"].includes(type)) {
      return new Response(JSON.stringify({ error: "type must be 'client' or 'competitor'" }), { status: 400 });
    }
    if (!name || !url) {
      return new Response(JSON.stringify({ error: "name and url are required" }), { status: 400 });
    }
    const wl = await addWatchlistItem(type, { name, url, feedUrl: feedUrl || null });
    return new Response(JSON.stringify(wl), {
      headers: { "content-type": "application/json" }
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), {
      status: 500,
      headers: { "content-type": "application/json" }
    });
  }
};

export const config = {
  path: "/api/watchlist-add"
};
