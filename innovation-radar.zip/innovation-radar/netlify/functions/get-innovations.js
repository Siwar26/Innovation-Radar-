import { getStoredData } from "../../shared/syncCore.js";

export default async () => {
  try {
    const { data, meta } = await getStoredData();
    return new Response(JSON.stringify({ items: data, meta }), {
      headers: {
        "content-type": "application/json",
        "cache-control": "public, max-age=60"
      }
    });
  } catch (e) {
    return new Response(JSON.stringify({ items: [], meta: null, error: e.message }), {
      status: 500,
      headers: { "content-type": "application/json" }
    });
  }
};

export const config = {
  path: "/api/innovations"
};
