import { removeWatchlistItem } from "../../shared/watchlistCore.js";

export default async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405 });
  }
  try {
    const { type, id } = await req.json();
    if (!type || !id) {
      return new Response(JSON.stringify({ error: "type and id are required" }), { status: 400 });
    }
    const wl = await removeWatchlistItem(type, id);
    return new Response(JSON.stringify(wl), {
      headers: { "content-type": "application/json" }
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), {
      status: 500,
      headers: { "content-type": "application/json" }
    });
  }
};

export const config = {
  path: "/api/watchlist-remove"
};
