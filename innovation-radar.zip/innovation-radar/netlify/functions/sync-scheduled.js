import { runSync } from "../../shared/syncCore.js";
import { runWatchlistSync } from "../../shared/watchlistCore.js";

// Fréquence configurable dans netlify.toml (par défaut: toutes les 6h).
export default async () => {
  try {
    const result = await runSync();
    await runWatchlistSync();
    console.log(`[sync-scheduled] OK — total=${result.total} new=${result.newCount}`);
    return new Response(JSON.stringify({ ok: true, ...result }), {
      headers: { "content-type": "application/json" }
    });
  } catch (e) {
    console.error("[sync-scheduled] FAILED", e);
    return new Response(JSON.stringify({ ok: false, error: e.message }), {
      status: 500,
      headers: { "content-type": "application/json" }
    });
  }
};

export const config = {
  schedule: "0 */6 * * *" // toutes les 6 heures — modifiable ici
};
