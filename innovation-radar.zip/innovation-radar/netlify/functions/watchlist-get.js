import { getWatchlist } from "../../shared/watchlistCore.js";

export default async () => {
  try {
    const wl = await getWatchlist();
    return new Response(JSON.stringify(wl), {
      headers: { "content-type": "application/json", "cache-control": "no-store" }
    });
  } catch (e) {
    return new Response(JSON.stringify({ clients: [], competitors: [], error: e.message }), {
      status: 500,
      headers: { "content-type": "application/json" }
    });
  }
};

export const config = {
  path: "/api/watchlist"
};
