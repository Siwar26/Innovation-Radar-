import { XMLParser } from "fast-xml-parser";
import { getStore } from "@netlify/blobs";

const BLOB_STORE = "innovation-radar";
const BLOB_KEY_WATCHLIST = "watchlist";

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: "@_",
  textNodeName: "#text"
});

function stripHtml(str = "") {
  return String(str)
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

function truncate(str, n) {
  if (!str) return "";
  return str.length > n ? str.slice(0, n - 1).trim() + "…" : str;
}

const FEED_HEADERS = {
  "User-Agent": "Mozilla/5.0 (compatible; AromatechInnovationRadar/1.0)",
  "Accept": "text/html,application/rss+xml,application/xml,*/*"
};

// ---------------------------------------------------------------------
// AUTO-DÉCOUVERTE DE FLUX RSS
// 1) On regarde si la page d'accueil déclare un flux via <link rel="alternate"
//    type="application/rss+xml" ...> (méthode standard, la plus fiable).
// 2) Sinon on teste une liste de chemins usuels (/feed, /rss.xml, etc.).
// Si rien ne fonctionne, la source reste "manual" (consultation via le lien direct).
// ---------------------------------------------------------------------
const COMMON_FEED_PATHS = [
  "/feed", "/feed/", "/rss", "/rss.xml", "/rss/", "/atom.xml",
  "/blog/feed", "/blog/rss", "/news/feed", "/press/feed", "/?feed=rss2"
];

async function looksLikeFeed(res) {
  if (!res.ok) return false;
  const ct = (res.headers.get("content-type") || "").toLowerCase();
  if (ct.includes("xml") || ct.includes("rss") || ct.includes("atom")) return true;
  // Certains serveurs mal configurés renvoient text/html pour un vrai flux : on vérifie le corps.
  const text = await res.text();
  return /<rss|<feed[\s>]/i.test(text.slice(0, 500));
}

export async function discoverFeed(siteUrl) {
  let base;
  try { base = new URL(siteUrl); } catch (e) { return null; }

  // 1) Chercher un <link rel="alternate" type="application/rss+xml" href="...">
  try {
    const res = await fetch(base.origin, { headers: FEED_HEADERS, signal: AbortSignal.timeout(10000) });
    if (res.ok) {
      const html = await res.text();
      const m = html.match(/<link[^>]+type=["']application\/(?:rss|atom)\+xml["'][^>]*href=["']([^"']+)["']/i)
             || html.match(/<link[^>]+href=["']([^"']+)["'][^>]*type=["']application\/(?:rss|atom)\+xml["']/i);
      if (m) {
        const feedUrl = new URL(m[1], base.origin).href;
        const check = await fetch(feedUrl, { headers: FEED_HEADERS, signal: AbortSignal.timeout(10000) });
        if (await looksLikeFeed(check)) return feedUrl;
      }
    }
  } catch (e) { /* on continue avec les chemins usuels */ }

  // 2) Essayer les chemins usuels
  for (const path of COMMON_FEED_PATHS) {
    try {
      const candidate = new URL(path, base.origin).href;
      const res = await fetch(candidate, { headers: FEED_HEADERS, signal: AbortSignal.timeout(8000) });
      if (await looksLikeFeed(res)) return candidate;
    } catch (e) { /* essai suivant */ }
  }
  return null;
}

function extractImage(item) {
  if (item["media:content"]) {
    const mc = Array.isArray(item["media:content"]) ? item["media:content"][0] : item["media:content"];
    if (mc && mc["@_url"]) return mc["@_url"];
  }
  if (item.enclosure && item.enclosure["@_url"]) return item.enclosure["@_url"];
  const html = item["content:encoded"] || item.description || "";
  const m = String(html).match(/<img[^>]+src=["']([^"']+)["']/i);
  return m ? m[1] : null;
}

async function fetchFeedItems(feedUrl) {
  const res = await fetch(feedUrl, { headers: FEED_HEADERS, signal: AbortSignal.timeout(15000) });
  if (!res.ok) throw new Error(`http-${res.status}`);
  const xml = await res.text();
  const json = parser.parse(xml);
  const channel = json?.rss?.channel || json?.feed;
  let rawItems = channel?.item || channel?.entry || [];
  if (!Array.isArray(rawItems)) rawItems = [rawItems];
  return rawItems.filter(Boolean).slice(0, 15).map(it => {
    const title = stripHtml(it.title?.["#text"] ?? it.title ?? "Sans titre");
    const link = it.link?.["@_href"] ?? (typeof it.link === "string" ? it.link : it.link?.["#text"]) ?? it.guid?.["#text"] ?? it.guid ?? "";
    const descRaw = it["content:encoded"] ?? it.description ?? it.summary ?? "";
    const pubDate = it.pubDate ?? it.published ?? it.updated ?? new Date().toISOString();
    return {
      title,
      description: truncate(stripHtml(descRaw), 200),
      image: extractImage(it),
      url: link,
      publishedAt: new Date(pubDate).toISOString()
    };
  });
}

// ---------------------------------------------------------------------
// WATCHLIST CRUD (Netlify Blobs)
// ---------------------------------------------------------------------
function emptyWatchlist() { return { clients: [], competitors: [] }; }

export async function getWatchlist() {
  const store = getStore(BLOB_STORE);
  return (await store.get(BLOB_KEY_WATCHLIST, { type: "json" })) || emptyWatchlist();
}

async function saveWatchlist(wl) {
  const store = getStore(BLOB_STORE);
  await store.setJSON(BLOB_KEY_WATCHLIST, wl);
  return wl;
}

function bucketKey(type) {
  return type === "client" ? "clients" : "competitors";
}

export async function addWatchlistItem(type, { name, url, feedUrl }) {
  const wl = await getWatchlist();
  const bucket = bucketKey(type);
  const id = "wl_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

  let resolvedFeed = feedUrl || null;
  let status = "pending";
  if (!resolvedFeed) {
    resolvedFeed = await discoverFeed(url);
  }
  status = resolvedFeed ? "active" : "manual";

  wl[bucket].push({
    id, name, url, feedUrl: resolvedFeed, status,
    addedAt: new Date().toISOString(), lastSync: resolvedFeed ? new Date().toISOString() : null,
    items: []
  });

  // Premier fetch immédiat si un flux a été trouvé
  if (resolvedFeed) {
    try {
      const items = await fetchFeedItems(resolvedFeed);
      wl[bucket][wl[bucket].length - 1].items = items;
    } catch (e) {
      wl[bucket][wl[bucket].length - 1].status = "warning";
      wl[bucket][wl[bucket].length - 1].error = e.message;
    }
  }

  return saveWatchlist(wl);
}

export async function removeWatchlistItem(type, id) {
  const wl = await getWatchlist();
  const bucket = bucketKey(type);
  wl[bucket] = wl[bucket].filter(c => c.id !== id);
  return saveWatchlist(wl);
}

// Resynchronise toutes les entrées de la watchlist qui ont un flux actif.
// Appelé par sync-now et sync-scheduled, en plus du sync des sources statiques.
export async function runWatchlistSync() {
  const wl = await getWatchlist();
  for (const bucket of ["clients", "competitors"]) {
    for (const entry of wl[bucket]) {
      if (!entry.feedUrl) continue; // reste "manual", rien à faire
      try {
        entry.items = await fetchFeedItems(entry.feedUrl);
        entry.status = "active";
        entry.lastSync = new Date().toISOString();
        entry.error = null;
      } catch (e) {
        entry.status = "warning";
        entry.error = e.message;
        entry.lastSync = new Date().toISOString();
      }
    }
  }
  await saveWatchlist(wl);
  return wl;
}
