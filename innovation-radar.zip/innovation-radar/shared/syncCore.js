import { XMLParser } from "fast-xml-parser";
import { getStore } from "@netlify/blobs";
import { SOURCES, TRENDS, AFRICA_MARKETS } from "./sources.js";

const BLOB_STORE = "innovation-radar";
const BLOB_KEY_DATA = "innovations";
const BLOB_KEY_META = "meta";

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: "@_",
  textNodeName: "#text"
});

function stripHtml(str = "") {
  return String(str)
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

function truncate(str, n) {
  if (!str) return "";
  return str.length > n ? str.slice(0, n - 1).trim() + "…" : str;
}

function extractImage(item) {
  // Try common RSS image locations: media:content, enclosure, content:encoded <img>
  if (item["media:content"]) {
    const mc = Array.isArray(item["media:content"]) ? item["media:content"][0] : item["media:content"];
    if (mc && mc["@_url"]) return mc["@_url"];
  }
  if (item["media:thumbnail"]) {
    const mt = Array.isArray(item["media:thumbnail"]) ? item["media:thumbnail"][0] : item["media:thumbnail"];
    if (mt && mt["@_url"]) return mt["@_url"];
  }
  if (item.enclosure && item.enclosure["@_url"]) return item.enclosure["@_url"];
  const html = item["content:encoded"] || item.description || "";
  const m = String(html).match(/<img[^>]+src=["']([^"']+)["']/i);
  if (m) return m[1];
  return null;
}

function detectTags(text) {
  const lower = text.toLowerCase();
  return TRENDS.filter(t => lower.includes(t.toLowerCase()));
}

function detectMarkets(text) {
  const lower = text.toLowerCase();
  const found = AFRICA_MARKETS.filter(m => lower.includes(m.toLowerCase()));
  return found;
}

function hashId(url, title) {
  const s = (url || title || "").toLowerCase();
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = (h << 5) - h + s.charCodeAt(i);
    h |= 0;
  }
  return "inv_" + Math.abs(h).toString(36);
}

async function fetchSourceItems(source) {
  if (!source.feedUrl) return { items: [], error: "no-feed-url" };
  try {
    const res = await fetch(source.feedUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; AromatechInnovationRadar/1.0; +https://aromatech.example)",
        "Accept": "application/rss+xml, application/xml, text/xml, */*"
      },
      signal: AbortSignal.timeout(15000)
    });
    if (!res.ok) return { items: [], error: `http-${res.status}` };
    const xml = await res.text();
    const json = parser.parse(xml);
    const channel = json?.rss?.channel || json?.feed;
    let rawItems = channel?.item || channel?.entry || [];
    if (!Array.isArray(rawItems)) rawItems = [rawItems];

    const items = rawItems.filter(Boolean).map(it => {
      const title = stripHtml(it.title?.["#text"] ?? it.title ?? "Sans titre");
      const link =
        it.link?.["@_href"] ??
        (typeof it.link === "string" ? it.link : it.link?.["#text"]) ??
        it.guid?.["#text"] ?? it.guid ?? "";
      const descRaw = it["content:encoded"] ?? it.description ?? it.summary ?? "";
      const description = truncate(stripHtml(descRaw), 220);
      const pubDate = it.pubDate ?? it.published ?? it.updated ?? new Date().toISOString();
      const image = extractImage(it);
      const fullText = title + " " + description;

      return {
        id: hashId(link, title),
        title,
        description,
        image,
        url: link,
        source: source.name,
        sourceId: source.id,
        category: source.category,
        country: source.country,
        tags: detectTags(fullText),
        africaMarkets: detectMarkets(fullText),
        publishedAt: new Date(pubDate).toISOString(),
        fetchedAt: new Date().toISOString()
      };
    });
    return { items, error: null };
  } catch (e) {
    return { items: [], error: e.message || "fetch-failed" };
  }
}

export async function runSync() {
  const store = getStore(BLOB_STORE);
  const existing = (await store.get(BLOB_KEY_DATA, { type: "json" })) || [];
  const existingIds = new Set(existing.map(x => x.id));

  // Sources RSS synchronisées automatiquement
  const sourcesToSync = SOURCES.filter(s => s.type === "rss" || s.type === "unverified");
  const sourceStatuses = [];
  let newCount = 0;
  const collected = [];

  for (const source of sourcesToSync) {
    const { items, error } = await fetchSourceItems(source);
    sourceStatuses.push({
      id: source.id,
      name: source.name,
      status: error ? (items.length ? "warning" : "error") : "active",
      error: error || null,
      lastSync: new Date().toISOString(),
      itemsFetched: items.length
    });
    for (const item of items) {
      collected.push(item);
      if (!existingIds.has(item.id)) newCount++;
    }
  }

  // Sources "manual" (ex: Mintel, Innova Market Insights) : activées et suivies,
  // mais sans sync RSS automatique — accès via login sur leur plateforme.
  // "unsupported" : aucun flux exploitable identifié.
  for (const source of SOURCES.filter(s => s.type === "manual" || s.type === "unsupported")) {
    sourceStatuses.push({
      id: source.id,
      name: source.name,
      status: source.type === "manual" ? "manual" : "error",
      error: source.type === "unsupported" ? "no-feed" : null,
      lastSync: null,
      itemsFetched: 0
    });
  }

  // Merge: new + existing, dedup by id, keep most recent 1000
  const merged = [...collected, ...existing];
  const seen = new Set();
  const deduped = [];
  for (const item of merged) {
    if (seen.has(item.id)) continue;
    seen.add(item.id);
    deduped.push(item);
  }
  deduped.sort((a, b) => new Date(b.publishedAt) - new Date(a.publishedAt));
  const trimmed = deduped.slice(0, 1000);

  await store.setJSON(BLOB_KEY_DATA, trimmed);

  const meta = {
    lastSync: new Date().toISOString(),
    total: trimmed.length,
    newSinceLastSync: newCount,
    sourceStatuses
  };
  await store.setJSON(BLOB_KEY_META, meta);

  return { total: trimmed.length, newCount, sourceStatuses };
}

export async function getStoredData() {
  const store = getStore(BLOB_STORE);
  const data = (await store.get(BLOB_KEY_DATA, { type: "json" })) || [];
  const meta = (await store.get(BLOB_KEY_META, { type: "json" })) || {
    lastSync: null,
    total: 0,
    newSinceLastSync: 0,
    sourceStatuses: SOURCES.map(s => ({
      id: s.id, name: s.name,
      status: s.type === "unsupported" ? "error" : s.type === "manual" ? "manual" : "warning",
      error: s.type === "unsupported" ? "no-feed" : null,
      lastSync: null, itemsFetched: 0
    }))
  };
  return { data, meta };
}
