// ============================================================================
// INNOVATION RADAR — Aromatech Afrique
// Configuration centralisée des sources surveillées.
// Pour ajouter une source : ajoutez un objet ici, rien d'autre à modifier.
//
// type:
//   "rss"         -> flux RSS confirmé ou très probable, sync automatique actif
//   "unverified"  -> flux non confirmé, sera testé au sync mais peut échouer
//   "unsupported" -> pas de flux exploitable identifié (voir tableau de
//                    faisabilité fourni). Affiché dans "Sources" avec un
//                    statut d'erreur, exclu du sync automatique.
// ============================================================================

export const SOURCES = [
  {
    id: "foodbev",
    name: "FoodBev Media",
    url: "https://www.foodbev.com",
    feedUrl: null,
    type: "unsupported",
    category: "Food & Beverage",
    country: "International",
    note: "Aucun flux RSS officiel identifié à ce jour."
  },
  {
    id: "foodnavigator",
    name: "FoodNavigator",
    url: "https://www.foodnavigator.com",
    feedUrl: "https://www.foodnavigator.com/Info/FoodNavigator-RSS",
    type: "rss",
    category: "Food & Beverage",
    country: "Europe"
  },
  {
    id: "foodingredientsfirst",
    name: "Food Ingredients First",
    url: "https://www.foodingredientsfirst.com",
    feedUrl: null,
    type: "unsupported",
    category: "Ingredients",
    country: "International",
    note: "Aucun flux RSS officiel confirmé malgré recherche — à re-tester périodiquement."
  },
  {
    id: "ingredientsnetwork",
    name: "Ingredients Network",
    url: "https://www.ingredientsnetwork.com",
    feedUrl: null,
    type: "unsupported",
    category: "Ingredients",
    country: "International",
    note: "Plateforme d'annuaire B2B, pas de contenu éditorial syndiqué."
  },
  {
    id: "innova",
    name: "Innova Market Insights",
    url: "https://www.innovamarketinsights.com",
    feedUrl: null,
    type: "manual",
    category: "Innovation / Trends",
    country: "International",
    note: "Activé comme source suivie. Plateforme sur abonnement (pas de flux RSS public) — accès et consultation via login Innova une fois les identifiants Aromatech obtenus. Contact: contact@innovami.com."
  },
  {
    id: "mintel",
    name: "Mintel",
    url: "https://www.mintel.com",
    feedUrl: null,
    type: "manual",
    category: "Consumer / Trends",
    country: "International",
    note: "Activé comme source suivie. Plateforme sur abonnement (pas de flux RSS public) — accès et consultation via login Mintel une fois l'abonnement Aromatech souscrit. Contact via store.mintel.com."
  },
  {
    id: "beveragedaily",
    name: "BeverageDaily",
    url: "https://www.beveragedaily.com",
    feedUrl: "https://www.beveragedaily.com/Info/BeverageDaily-RSS",
    type: "rss",
    category: "Beverage",
    country: "Europe"
  },
  {
    id: "bevnet",
    name: "BevNET",
    url: "https://www.bevnet.com",
    feedUrl: "https://www.bevnet.com/feed/",
    type: "rss",
    category: "Beverage",
    country: "USA",
    note: "Flux confirmé (bevnet.com propose plusieurs flux RSS dédiés)."
  },
  {
    id: "dairyreporter",
    name: "DairyReporter",
    url: "https://www.dairyreporter.com",
    feedUrl: "https://www.dairyreporter.com/Info/DairyReporter-RSS",
    type: "rss",
    category: "Dairy",
    country: "Europe"
  },
  {
    id: "bakeryandsnacks",
    name: "BakeryAndSnacks",
    url: "https://www.bakeryandsnacks.com",
    feedUrl: "https://www.bakeryandsnacks.com/Info/BakeryAndSnacks-RSS",
    type: "rss",
    category: "Bakery",
    country: "Europe"
  },
  {
    id: "confectionerynews",
    name: "ConfectioneryNews",
    url: "https://www.confectionerynews.com",
    feedUrl: "https://www.confectionerynews.com/Info/ConfectioneryNews-RSS",
    type: "rss",
    category: "Confectionery",
    country: "Europe"
  },
  {
    id: "perfumerflavorist",
    name: "Perfumer & Flavorist",
    url: "https://www.perfumerflavorist.com",
    feedUrl: null,
    type: "unsupported",
    category: "Flavors",
    country: "USA",
    note: "Aucun flux RSS officiel confirmé malgré recherche — à re-tester périodiquement."
  },
  {
    id: "foodbusinessnews",
    name: "Food Business News",
    url: "https://www.foodbusinessnews.net",
    feedUrl: "https://www.foodbusinessnews.net/rss/articles",
    type: "rss",
    category: "Food Industry",
    country: "USA"
  },
  {
    id: "justfood",
    name: "Just Food",
    url: "https://www.just-food.com",
    feedUrl: "https://www.just-food.com/feed",
    type: "rss",
    category: "FMCG / Food Industry",
    country: "International"
  },
  {
    id: "nutraingredients",
    name: "NutraIngredients",
    url: "https://www.nutraingredients.com",
    feedUrl: "https://www.nutraingredients.com/Info/NutraIngredients-RSS",
    type: "rss",
    category: "Nutrition / Functional",
    country: "Europe"
  },
  {
    id: "fooddive",
    name: "Food Dive",
    url: "https://www.fooddive.com",
    feedUrl: "https://www.fooddive.com/feeds/news/",
    type: "rss",
    category: "Food Industry",
    country: "USA",
    note: "Flux confirmé — actualités et innovation food industry (Industry Dive)."
  },
  {
    id: "vegconomist",
    name: "vegconomist (Food & Beverage)",
    url: "https://vegconomist.com/category/food-and-beverage/",
    feedUrl: "https://vegconomist.com/category/food-and-beverage/feed/",
    type: "rss",
    category: "Plant-Based / Food & Beverage",
    country: "International",
    note: "Flux confirmé — inclut une couverture Afrique (vegconomist.com/region/africa)."
  },
  {
    id: "foodbusinessafrica",
    name: "Food Business Africa",
    url: "https://www.foodbusinessafrica.com",
    feedUrl: "https://www.foodbusinessafrica.com/feed",
    type: "rss",
    category: "Food & Beverage — Africa",
    country: "Africa",
    note: "Flux confirmé — 1ère publication food/beverage/milling en Afrique subsaharienne."
  },
  {
    id: "foodsafetyafrica",
    name: "Food Safety Africa",
    url: "https://www.foodsafetyafrica.net",
    feedUrl: "https://www.foodsafetyafrica.net/feed",
    type: "rss",
    category: "Food Safety — Africa",
    country: "Africa",
    note: "Flux confirmé — référence food safety/quality/compliance en Afrique."
  },
  {
    id: "fbreporter",
    name: "Food & Beverage Reporter (South Africa)",
    url: "https://fbreporter.co.za",
    feedUrl: "https://fbreporter.co.za/feed",
    type: "rss",
    category: "Food & Beverage — Southern Africa",
    country: "Africa",
    note: "Flux confirmé — food, beverage & packaging en Afrique australe."
  },
  {
    id: "howwemadeitinafrica",
    name: "How We Made It In Africa",
    url: "https://www.howwemadeitinafrica.com",
    feedUrl: "https://www.howwemadeitinafrica.com/feed",
    type: "rss",
    category: "African Business",
    country: "Africa",
    note: "Flux confirmé — entrepreneuriat et business africain, inclut food/bev régulièrement."
  },
  {
    id: "bevindustry",
    name: "Beverage Industry",
    url: "https://www.bevindustry.com",
    feedUrl: "https://www.bevindustry.com/rss/16",
    type: "rss",
    category: "Beverage",
    country: "USA",
    note: "Flux officiel confirmé (BNP Media) — trends, formulation, technology & products. Flux additionnels par catégorie disponibles (alcool, eau, énergie, packaging…)."
  }
];

// ============================================================================
// LIENS DE RÉFÉRENCE MANUELS (non synchronisés)
// LinkedIn n'offre plus de flux RSS depuis 2013 (fonctionnalité officiellement
// supprimée) et le scraping de LinkedIn viole ses conditions d'utilisation.
// Ces liens sont donc listés ici comme références à consulter manuellement,
// PAS comme sources synchronisées automatiquement par sync-scheduled.js.
// ============================================================================
export const MANUAL_LINKS = [
  { name: "Food Business Africa — LinkedIn", url: "https://www.linkedin.com/company/food-business-africa-official-page", note: "Actualités food/beverage/milling Afrique" },
  { name: "Innova Market Insights — LinkedIn", url: "https://www.linkedin.com/company/innova-market-insights", note: "Tendances marché mondial (source sur abonnement)" },
  { name: "Mintel — LinkedIn", url: "https://www.linkedin.com/company/mintel", note: "Tendances consommateur mondial (source sur abonnement)" },
  { name: "How We Made It In Africa — LinkedIn", url: "https://www.linkedin.com/company/how-we-made-it-in-africa", note: "Entrepreneuriat africain" }
];
export const APPLICATIONS = [
  "Dairy", "Beverage", "Bakery", "Confectionery", "Savoury",
  "Ice Cream", "Sauces", "Snacks", "Nutrition", "Other"
];

// Tendances suivies pour le Trend Radar (mots-clés détectés dans titre/description)
export const TRENDS = [
  "Ube", "Pandan", "Matcha", "Protein", "Healthy", "Botanical",
  "Natural", "NOLO", "Hard Seltzer", "Functional", "Plant-Based",
  "Premium", "Tropical", "Exotic"
];

// Marchés / pays pour les filtres et pour Africa Focus
export const MARKETS = [
  "Tunisia", "Algeria", "Morocco", "Egypt", "Côte d'Ivoire",
  "Senegal", "Libya", "Africa", "Europe", "USA", "Asia", "International"
];

export const AFRICA_MARKETS = [
  "Tunisia", "Algeria", "Morocco", "Egypt", "Côte d'Ivoire",
  "Senegal", "Libya", "Africa"
];
